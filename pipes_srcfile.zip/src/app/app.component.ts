import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipes';
  name:string = '';
  date:string = '';
  amount : number=0;

  onNameChange(event:Event){
    const inputElement = event.target as HTMLInputElement;
    this.name=inputElement.value;
  }

  onDateChange(event: Event){
    const inputElement = event.target as HTMLInputElement;
    this.date=inputElement.value;
  }

  onAmountChange(event: Event){
    const inputElement = event.target as HTMLInputElement;
    this.amount=parseFloat(inputElement.value);

  }
}
