import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pw';
  password = "";
  length = 0;
  useLetters = false;
  useNumbers = false;
  useSymbols = false;

  onChangeLength(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    const parsedValue = parseInt(value, 10);
    if (!isNaN(parsedValue)) {
      this.length = parsedValue;
    }
  }
  

  onChangeUseLetters(){
    this.useLetters=!this.useLetters;
  }

  onChangeUseNumbers(){
    this.useNumbers=!this.useNumbers;
  }

  onChangeUseSymbols(){
    this.useSymbols=!this.useSymbols;
  }
  onButtonClick(){
   const numbers = '0123456789';

   //Combining Arrays: ... (spread operator) merges the two arrays, and join('') combines them into a single string.

   const letters = [...Array.from({length: 26}, (_, i) => String.fromCharCode(97 + i)), // a-z 
    ...Array.from({length: 26}, (_, i) => String.fromCharCode(65 + i)) // A-Z
   ].join('');
   const symbols = '!@#$%^&*()<>?/~_';
   let validChars = '';

if(this.useLetters){
  validChars+=letters;
}
if(this.useNumbers){
  validChars+=numbers;
}
if(this.useSymbols){
  validChars+=symbols;
}

let generatePassword = '';
for(let i=0 ; i<this.length;i++){
  const index = Math.floor(Math.random()*validChars.length);
  // Math.random returns a floating number and array elements indexes are actually integers. Math.floor rounds the float down to the nearest integer.
  generatePassword += validChars[index];
}
this.password=generatePassword;
  }



}
