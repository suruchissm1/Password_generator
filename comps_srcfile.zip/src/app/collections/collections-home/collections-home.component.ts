import { Component } from '@angular/core';

@Component({
  selector: 'app-collections-home',
  templateUrl: './collections-home.component.html',
  styleUrls: ['./collections-home.component.css']
})
export class CollectionsHomeComponent {
  data:{ name: string, age: string, job: string }[]=[
    {name: 'Suruchi' , age:'22', job:'Engineer' },
    {name: 'Sameer',age:'25', job:'Business'},
    {name:'Pallawi' ,age: '24', job:'Doctor'}];

  headers:{ key: string, label: string }[]=[
    {key:'name', label: 'Name'},
    {key:'age', label: 'Age'},
    {key:'job', label: 'Job'}
  ]
}
