import { Component } from '@angular/core';

@Component({
  selector: 'app-views-home',
  templateUrl: './views-home.component.html',
  styleUrls: ['./views-home.component.css']
})
export class ViewsHomeComponent {
stats=[
  {value: 22, label:'No. of Users'},
  {value: 900, label:'Revenue'},
  {value: 225, label:'Satisfaction Score'},
];
items=[
  {images:'assets/images/couch.jpeg', title:'Couch', description:'Fantastic couch'},
  {images:'assets/images/dresser.jpeg', title:'Dresser', description:'Good dresser'},
]

}
