import { Component } from '@angular/core';

@Component({
  selector: 'app-mods-home',
  templateUrl: './mods-home.component.html',
  styleUrls: ['./mods-home.component.css']
})
export class ModsHomeComponent {
modalOpen = false;

items = [
  {title:'What is the largest living creature on Earth?', content:'The blue whale is the largest living creature on Earth.'},
  {title:'What is the name of the worlds longest river?', content:'The Nile River is the world longest river.'},
  {title:'Why do flowers have different colors and smells?', content:'Flowers have different colors and smells because they have different characteristics'},
  {title:'Why do some areas have more red maples than sugar maples? ', content:'Different maples have different habitat needs.'}
]

onClick(){
  this.modalOpen=!this.modalOpen;
}
}

